import uuid

from django.conf import settings
from django.db import models


class Publisher(models.Model):
    name = models.CharField(max_length=100)
    website = models.URLField()
    founded = models.DateField()


class Author(models.Model):
    name = models.CharField(max_length=100)
    slug = models.SlugField(unique=True)
    birth_date = models.DateField()
    publisher = models.ForeignKey(Publisher, on_delete=models.CASCADE)
    uid = models.UUIDField(default=uuid.uuid4, editable=False)


class Tag(models.Model):
    name = models.CharField(max_length=30)


class Book(models.Model):
    title = models.CharField(max_length=200)
    author = models.ForeignKey(Author, on_delete=models.CASCADE)
    publisher = models.ForeignKey(Publisher, on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=6, decimal_places=2)
    pages = models.PositiveIntegerField()
    isbn_number = models.BigIntegerField()
    published_at = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)
    cover = models.FileField(upload_to="covers/", blank=True)
    tags = models.ManyToManyField(Tag, blank=True)


class Category(models.Model):
    name = models.CharField(max_length=50)
    parent = models.ForeignKey("self", null=True, blank=True, on_delete=models.CASCADE)


class Review(models.Model):
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    reviewer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    rating = models.PositiveSmallIntegerField()
    body = models.TextField()


class Profile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    bio = models.TextField()


class Archive(models.Model):
    """Required JSONField with no default: the generator cannot fill it, so it must skip this model."""
    payload = models.JSONField()
