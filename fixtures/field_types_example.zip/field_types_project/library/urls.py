from django.urls import path

from . import views

app_name = "library"

urlpatterns = [
    path("books/", views.book_list, name="book-list"),
    path("books/<int:pk>/", views.book_detail, name="book-detail"),
    path("books/<int:pk>/rate/", views.book_rate, name="book-rate"),
    path("authors/new/", views.AuthorCreateView.as_view(), name="author-create"),
    path("authors/<slug:slug>/", views.AuthorDetailView.as_view(), name="author-detail"),
    path("books/new/", views.book_create, name="book-create"),
    path("books/<int:pk>/edit/", views.book_edit, name="book-edit"),
    path("books/<int:pk>/delete/", views.BookDeleteView.as_view(), name="book-delete"),
    path("account/", views.account, name="account"),
    path("archive/<int:year>/", views.archive_year, name="archive-year"),
]
