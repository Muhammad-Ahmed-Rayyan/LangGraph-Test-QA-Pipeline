from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, DetailView

from .forms import BookForm
from .models import Author, Book


def book_list(request):
    return render(request, "library/book_list.html", {"books": Book.objects.all()})


def book_detail(request, pk):
    book = get_object_or_404(Book, pk=pk)
    return render(request, "library/book_detail.html", {"book": book})


class AuthorDetailView(DetailView):
    model = Author
    slug_field = "slug"
    template_name = "library/author_detail.html"


@login_required
def account(request):
    return HttpResponse("account page for " + request.user.get_username())


@require_POST
def book_rate(request, pk):
    return HttpResponse("rated")


def archive_year(request, year):
    return HttpResponse(f"year {year}")


def book_create(request):
    if request.method == "POST":
        form = BookForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("library:book-list")
    else:
        form = BookForm()
    return render(request, "library/book_form.html", {"form": form})


def book_edit(request, pk):
    book = get_object_or_404(Book, pk=pk)
    if request.method == "POST":
        form = BookForm(request.POST, instance=book)
        if form.is_valid():
            form.save()
            return redirect("library:book-detail", pk=book.pk)
    else:
        form = BookForm(instance=book)
    return render(request, "library/book_form.html", {"form": form})


class AuthorCreateView(CreateView):
    model = Author
    fields = ["name", "slug", "birth_date", "publisher"]
    template_name = "library/author_form.html"
    success_url = reverse_lazy("library:book-list")


class BookDeleteView(DeleteView):
    model = Book
    template_name = "library/book_confirm_delete.html"
    success_url = reverse_lazy("library:book-list")
