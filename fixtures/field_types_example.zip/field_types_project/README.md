Scratch Django project used as a test fixture for the unit test generator.
It covers the model field types the generator supports, plus relations.
